package com.cdac.dao;

import java.util.List;


import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

import com.cdac.entity.Employee;

public class ImprovedEmployeeDao2 
{
	
	public static EntityManagerFactory emf;
	static {
	           Persistence.createEntityManagerFactory("learing-hibernate");
	           Runtime.getRuntime().addShutdownHook(new Thread(()->emf.close()));
	
	}
	
	
	public void add(Employee emp)
	{
		
        EntityManager em=emf.createEntityManager();
        EntityTransaction tx=em.getTransaction();
        tx.begin();
        
        em.persist(emp); // persist methode will generate insert query
        tx.commit();
        
	}
	public Employee fetchData(int empno)
	{
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("learing-hibernate");
		EntityManager em=emf.createEntityManager();
		Employee emp=em.find(Employee.class, empno);
		
		return emp;
	}
	public List<Employee> fetchAll(){
		
		EntityManager em=emf.createEntityManager();
		Query q=em.createQuery("select e from Employee e");
		List<Employee> list=q.getResultList();
		
		return list;	
	}
	public List<String> fetchAllNames()
	{
		
		EntityManager em=emf.createEntityManager();
		Query q=em.createQuery("select e.name from Employee e");
		List<String> names=q.getResultList();
		return names;
	}
	public List<Object[]> fetchNameAndSalaries()
	{
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("learing-hibernate");
		EntityManager em=emf.createEntityManager();
		Query q=em.createQuery("select e.name,e.salary from Employee e");
		List<Object[]> nameAndSalaries=q.getResultList();
		return nameAndSalaries;
	}
	
	public List<Employee> fetchAllBySalary(double salary)
	{
		
		EntityManager em=emf.createEntityManager();
		Query q=em.createQuery("select e from Employee e where e.salary>:sal");
		q.setParameter("sal", salary);
		List<Employee> list=q.getResultList();
		return list;
	}

}
