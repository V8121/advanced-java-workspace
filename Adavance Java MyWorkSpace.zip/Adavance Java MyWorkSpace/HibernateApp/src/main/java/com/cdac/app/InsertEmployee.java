package com.cdac.app;

import java.time.LocalDate;
import java.util.List;

import com.cdac.dao.EmployeeDao;
import com.cdac.entity.Employee;



public class InsertEmployee 
{
	/*public static void main(String [] args) 
	{
            EntityManagerFactory emf=Persistence.createEntityManagerFactory("learing-hibernate");
            EntityManager em=emf.createEntityManager();
            EntityTransaction tx=em.getTransaction();
            tx.begin();
            Employee emp=new Employee();
            emp.setEmpno(101);
            emp.setName("Sai");
            emp.setSalary(1123456789);
            emp.setDateOfJoinig(LocalDate.of(2022, 3, 7));
            em.persist(emp); // persist methode will generate insert query
            tx.commit();
            emf.close();
            
	}*/
	
	public static void main(String [] args) 
	{
		
		/*EmployeeDao empdao=new EmployeeDao();
		Employee emp=new Employee();
		emp.setEmpno(102);
		emp.setName("swapnil");
		emp.setSalary(5000000);
		emp.setDateOfJoinig(LocalDate.of(2022, 4, 7));
		empdao.add(emp);*/  // To insert Record
		
		/*EmployeeDao empdao=new EmployeeDao();
		Employee emp=empdao.fetchData(102);
		System.out.println(emp.getName()+" "+emp.getSalary());*/
		
		EmployeeDao empdao=new EmployeeDao();
		
	/*	List<Employee> list=empdao.fetchAll();
		
		for(Employee emp:list)
		{
			System.out.println(emp.getEmpno()+" "+emp.getName()+" "+emp.getSalary()+" "+emp.getDateOfJoinig());
		}
		
		System.out.println("....................................................................");
		List<String> names=empdao.fetchAllNames();
		for(String nm:names)
		{
			System.out.println(nm);
		}
		System.out.println("....................................................................");
		
		List<Object[]>nameAndSalaries=empdao.fetchNameAndSalaries();
		for(Object [] arr:nameAndSalaries)
		{
			System.out.println(arr[0]+" "+arr[1]);
		}
		
		System.out.println("....................................................................");		
		*/
		List<Employee> list2=empdao.fetchAllBySalary(750000000);
		for(Employee sal:list2)
		{
			System.out.println(sal);
		}
	}
}
