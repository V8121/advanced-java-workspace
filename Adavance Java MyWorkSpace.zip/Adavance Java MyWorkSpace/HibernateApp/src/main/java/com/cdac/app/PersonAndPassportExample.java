package com.cdac.app;

import java.time.LocalDate;
import java.util.List;

import com.cdac.dao.PersonAndPassportDao;
import com.cdac.entity.Passport;
import com.cdac.entity.Person;

public class PersonAndPassportExample {

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		
		PersonAndPassportDao dao=new PersonAndPassportDao();
		
		/*Person p=new Person();
		p.setName("swapnil");
		p.setEmail("swapnil@gmail.com");
		p.setDateOfBirth(LocalDate.of(1994, 06, 11));
		
		Passport pass=new Passport();
		pass.setIssueDate(LocalDate.of(2020, 12, 30));
		pass.setExpiryDate(LocalDate.of(2030, 12, 30));
		pass.setIssuedBy("Govt.Of India");
		
		p.setPassport(pass);
		pass.setPerson(p);
		dao.addPerson(p);*/
		
		/*Person p=dao.fetchPersonByPassportNo(5);
		System.out.println(p.getName()+" "+p.getEmail());*/
		
		List<Person> list=dao.fetchPersonByPassportExipryYear(2025);
		for(Person per:list)
		{
			System.out.println(per.getName()+" "+per.getEmail()+" "+per.getId());
		}
		
		

	}

}
