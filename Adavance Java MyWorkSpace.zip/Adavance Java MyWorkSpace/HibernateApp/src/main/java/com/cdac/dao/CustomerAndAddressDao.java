package com.cdac.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.transaction.Transaction;



import com.cdac.entity.Address;
import com.cdac.entity.Customer;

public class CustomerAndAddressDao 
{
	
	public void add(Customer cust) 
	{
	       EntityManagerFactory emf=Persistence.createEntityManagerFactory("learing-hibernate");
	       EntityManager em=emf.createEntityManager();
	       EntityTransaction tx=em.getTransaction();
	       tx.begin();
	       em.persist(cust);
	       tx.commit();
	       emf.close();
	}
	public void add(Address add)
	{
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("learing-hibernate");
	       EntityManager em=emf.createEntityManager();
	       EntityTransaction tx=em.getTransaction();
	       tx.begin();
	       em.persist(add);
	       tx.commit();
	       emf.close();
		
	}
	public void update(Customer cust)
	{
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("learing-hibernate");
	       EntityManager em=emf.createEntityManager();
	       EntityTransaction tx=em.getTransaction();
	       tx.begin();
	       em.merge(cust);
	       tx.commit();
	       emf.close();
	}
	
	public Customer fetchCustomer(int id)
	{
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("learing-hibernate");
	       EntityManager em=emf.createEntityManager();
	       EntityTransaction tx=em.getTransaction();
	       tx.begin();
	      Customer cust= em.find(Customer.class, id);
	       tx.commit();
	       emf.close();
	       return cust;
	}
	public Address fetchAddress(int id)
	{
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("learing-hibernate");
	       EntityManager em=emf.createEntityManager();
	       EntityTransaction tx=em.getTransaction();
	       tx.begin();
	      Address add= em.find(Address.class, id);
	       tx.commit();
	       emf.close();
	       return add;
	}
	
	public List<Customer> fetchDataByEmail(String domain)
	{
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("learing-hibernate");
		EntityManager em=emf.createEntityManager();
		Query q=em.createQuery("select c from Customer c where c.email like:em"); // like Special Operator in sql
		q.setParameter("em","%" +domain+"%");
		List<Customer> list=q.getResultList();
		return list;
		
	}
	
	public List<Customer> fetchCustomerByCity(String city)
	{
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("learing-hibernate");
		EntityManager em=emf.createEntityManager();
		Query q=em.createQuery("select c from Customer c join c.address where city=:ct");
		q.setParameter("ct", city);
		List<Customer> list=q.getResultList();
		return list;
	}
	
	
	
}
