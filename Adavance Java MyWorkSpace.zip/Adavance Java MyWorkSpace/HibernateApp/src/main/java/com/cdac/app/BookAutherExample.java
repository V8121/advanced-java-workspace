package com.cdac.app;

import java.util.ArrayList;
import java.util.List;

import com.cdac.dao.GenericDao;
import com.cdac.entity.Auther;
import com.cdac.entity.Book;

public class BookAutherExample {

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		
		GenericDao dao=new GenericDao();
		// Adding Some Authers in tbl_Auther
		/*Auther auther=new Auther();
		auther.setName("Elisabeth Robson");
		auther.setEmail("elisabeth@gamil.com");
		dao.save(auther);*/
		
		/*Book book=new Book();
		book.setName("First Head Dessign Pattern");
		book.setCost(225);
		List<Auther> authers= new ArrayList<>();
		authers.add((Auther)dao.fetchById(Auther.class, 1));
		authers.add((Auther)dao.fetchById(Auther.class, 2));
		book.setAuthers(authers);
		dao.save(book);*/
		
		//Assuming that first we want to add book
		//Book book =new Book();
		/*book.setName("First Head JavaScript");
		book.setCost(115);
		dao.save(book);*/
		
		// then Mention the Authers for this exiting book
		
		/*Book books=(Book)dao.fetchById(Book.class, 2);
		List<Auther> authers=new ArrayList<Auther>();
		authers.add((Auther)dao.fetchById(Auther.class, 1));
		authers.add((Auther)dao.fetchById(Auther.class, 2));
		books.setAuthers(authers);
		dao.save(books);*/
		
		Book book=new Book();
		book.setName("Ottolenghi Flavor");
		book.setCost(2400);
		
		Auther auther1=new Auther();
		auther1.setName("Ixta Belfrage ");
		auther1.setEmail("Ixta@gnail.com");
		
		Auther auther2=new Auther();
		auther2.setName("Yotam Ottolenghi");
		auther2.setEmail("Yotam@gmail.com");
		
		List<Auther>list=new ArrayList<Auther>();
		list.add(auther1);
		list.add(auther2);
		book.setAuthers(list);
		dao.save(book);
				
		
		
		
		
		
		
	}

}
