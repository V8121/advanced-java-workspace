package com.cdac.app;

import java.time.LocalDate;
import java.util.List;

import com.cdac.dao.AlbumSongDao;
import com.cdac.dao.GenericDao;
import com.cdac.entity.Album;
import com.cdac.entity.Song;

public class AlbumAndSongs
{

	public static void main(String[] args)
	{
		// TODO Auto-generated method stub
		// Adding Album 
		GenericDao dao=new GenericDao();
		/*Album album=new Album();
		album.setName("Hits Of 2022");
		album.setReleaseDate(LocalDate.of(2022, 12, 30));
		album.setCopyRight("Sony Musics Pvt Ltd");
		dao.save(album);*/
		
		/*Album album=(Album)dao.fetchById(Album.class, 7);
		Song song=new Song();
		song.setTitle("YYYYY");
		song.setArtist("Sonu Nigam");
		song.setDuration(4.35);
		song.setAlbum(album);
		dao.save(song);*/
		
		/*AlbumSongDao asdao= new AlbumSongDao();
		
	List<Song> song	=asdao.fetchSongByArtist("mika singh");
	
	for(Song songs:song)
	{
		System.out.println(songs.getTitle()+" "+songs.getArtist()+" "+songs.getDuration());
	}*/
	  
		 dao.delete(Song.class,9);
		 
		
		

	}

}
