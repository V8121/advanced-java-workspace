package com.cdac.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

import com.cdac.entity.Song;



public class AlbumSongDao extends GenericDao
{

	public List<Song> fetchSongByArtist(String artist)
	{
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("learing-hibernate" );
		   try 
		   {
			   EntityManager em=emf.createEntityManager();
			   //EntityTransaction tx=em.getTransaction();
			   //tx.begin();
			   Query q=em.createQuery("select s from Song s where s.artist=:ar");
			  q.setParameter("ar", artist);
			   List<Song>list=q.getResultList();
			  // tx.commit();
			   return list;
		   }finally {
			emf.close();
		}
	}
	
}
