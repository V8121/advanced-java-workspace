package com.cdac.app;

import java.util.List;

import com.cdac.dao.CustomerAndAddressDao;
import com.cdac.entity.Address;
import com.cdac.entity.Customer;

public class AddCustomerAndAddress {

	public static void main(String[] args) 
	{
		CustomerAndAddressDao custandAdd=new CustomerAndAddressDao();
		
		/*Customer c=new Customer();
		//c.setId(101);
		c.setName("MereSai");
		c.setEmail("omSai501@gmail.com");
		custandAdd.add(c);
		
		Address a=new Address();
		//a.setId(100);
		a.setCity("shirdi");
		a.setPincode(12345);
		a.setState("MH");
		
		custandAdd.add(a);*/
		
		//Customer cust=new Customer();
		//Address add=new Address();
		
		
		/*Customer c=custandAdd.fetchCustomer(1);
		Address a=custandAdd.fetchAddress(1);         // Establishing Relationship customer and aslo use Update statement
		
		c.setAddress(a);
		custandAdd.update(c);*/
		
		Customer c=new Customer();
		Address a =new Address();
		
		/*c.setName("Samir");
		c.setEmail("samir@gmail.com");
		
		a.setCity("Nanded");
		a.setPincode(431718);
		a.setState("MH");
		c.setAddress(a);
		c.setAddress(a);
		custandAdd.add(c);*/
		
	/*	c.setName("vikas");
		c.setEmail("vikas@outlook");
		
		a.setCity("pune");
		a.setPincode(410507);
		a.setState("MH");
		
		c.setAddress(a);
		custandAdd.add(c);
		
		List<Customer> list=custandAdd.fetchDataByEmail("outlook");
		
		for(Customer cust:list)              // Like Special Operator  in Sql 
		{
			System.out.println(cust.getId()+" "+cust.getName()+" "+cust.getEmail());
		}*/
		
		List<Customer> list=custandAdd.fetchCustomerByCity("pune");
		for(Customer cust:list)
		{
			System.out.println(cust.getId()+" "+cust.getName()+" "+cust.getEmail());
		}
		
		
	}

}
