package com.cdac.entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

@Entity
@Table(name="tbl_Book")
public class Book 
{
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	private String name;
	private double cost;
	
	@ManyToMany(cascade = CascadeType.ALL)
	@JoinTable(name="tbl_Book_Auther",
	joinColumns=@JoinColumn(name="Book_id"),
	inverseJoinColumns =@JoinColumn (name="Auther_id"))
	private List<Auther>authers;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getCost() {
		return cost;
	}

	public void setCost(double cost) {
		this.cost = cost;
	}

	public List<Auther> getAuthers() {
		return authers;
	}

	public void setAuthers(List<Auther> authers) {
		this.authers = authers;
	}
	
	

}
