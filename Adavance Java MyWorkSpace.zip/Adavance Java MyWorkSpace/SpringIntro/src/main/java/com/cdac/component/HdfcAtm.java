package com.cdac.component;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component("hdfcatm-v1")
public class HdfcAtm implements Atm {

	@Autowired
	private Bank bank;
	public void withDraw(int acno, double ammount) 
	{
		System.out.println("custmer come to hdfc atm to withdraw ammount");
	   bank.withDraw(12345, acno, ammount);

	}

}
