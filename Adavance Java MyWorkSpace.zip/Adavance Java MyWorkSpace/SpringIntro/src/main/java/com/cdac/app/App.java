package com.cdac.app;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cdac.component.Atm;
import com.cdac.component.Calculator;
import com.cdac.component.Car;
import com.cdac.component.CurrencyConverter;
import com.cdac.component.HelloWorld;
import com.cdac.component.TextEditer;

public class App {

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		//Loading Spring/IoC container
		ApplicationContext ctx=new ClassPathXmlApplicationContext("my-spring-config.xml");
		   HelloWorld hw=(HelloWorld)ctx.getBean("hello");
		   System.out.println(hw.sayHello("swapnil"));
		   // But Why we are using Spring To create objects of HelloWorld class?
		   //We could have cretae object on our like this;
		   //HelloWorld hw=new HelloWorld
		   
		   Calculator cal=(Calculator)ctx.getBean("calc");
		   System.out.println(cal.add(30, 20));
		   System.out.println(cal.sub(30, 20));
		   
		   CurrencyConverter cc=( CurrencyConverter)ctx.getBean("CurremcyCuvr");
		   System.out.println(cc.doConvert("USD", "INR", 650));
		   
		   TextEditer tx=(TextEditer)ctx.getBean("txtedt");
		   tx.load("abc.txt");
		   
		   Car c=(Car)ctx.getBean("car");
		   c.drive();
		   
		   Atm atm=(Atm)ctx.getBean("hdfcatm-v1");
		   atm.withDraw(110101, 50000);

	}

}
