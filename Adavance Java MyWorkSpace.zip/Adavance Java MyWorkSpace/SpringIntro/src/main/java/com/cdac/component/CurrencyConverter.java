package com.cdac.component;

import org.springframework.stereotype.Component;

@Component("CurremcyCuvr")
public class CurrencyConverter
{
	
	public double doConvert(String from,String to,double ammount)
	{
		if(from.equals("USD") && to.equals("INR"))
			return 78.98*ammount;
		else if(from.equals("POUND") && to.equals("INR"))
			return 94.41*ammount;
		else 
			return 0;  // here we have to use user Define Exception handling
	}

}
