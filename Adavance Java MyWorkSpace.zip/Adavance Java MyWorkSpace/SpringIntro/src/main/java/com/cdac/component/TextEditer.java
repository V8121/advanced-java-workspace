package com.cdac.component;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Conditional;
import org.springframework.stereotype.Component;

@Component("txtedt")
public class TextEditer 
{ 
	@Autowired    // DI(dependency Injection) // Ioc 
    private SpellChecker sp;
	
    public void load(String document)
    {
    	System.out.println("some code for text-editer"+document);
    	
    	//from here we want to invoke Spellchecker methode  
    	// in normal core we can do it as
    	//SpellChecker sp=new SpellChecker();
    	// but we want spring to create Requited object of spellcheker
    	sp.checkSpellingMistake(document);
    }
}
