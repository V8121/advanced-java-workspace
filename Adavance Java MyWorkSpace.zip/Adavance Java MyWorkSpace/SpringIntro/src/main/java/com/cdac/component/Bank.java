package com.cdac.component;

public interface Bank 
{
     public void withDraw(int atmId,int acno,double ammount);
}
