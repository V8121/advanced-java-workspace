package com.cdac.component;

public interface Atm 
{
   public void withDraw(int acno,double ammount);
   
}
