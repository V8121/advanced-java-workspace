package com.cdac.component;

import org.springframework.stereotype.Component;

@Component("citibank-v1")
public class CitiBank implements Bank {

	public void withDraw(int atmId, int acno, double ammount) 
	{
		System.out.println("in citibank Withdrawal methode");

	}

}
