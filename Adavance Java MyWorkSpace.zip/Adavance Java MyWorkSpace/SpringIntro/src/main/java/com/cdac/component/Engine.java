package com.cdac.component;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component("engine")

public class Engine
{
    
	 public void on()
	 {
		 System.out.println("Sound When Engine Start vroom...vroom...");
	 }
    
	 public void off()
	 {
		 System.out.println("Sound When Engine off phoosh....phoosh....");
	 }
}
