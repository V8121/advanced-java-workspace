package com.cdac.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cdac.model.Question;
import com.cdac.model.questionBankLoader;

/**
 * Servlet implementation class QuestionLoaderServlet
 */
@WebServlet("/QuestionLoaderServlet")
public class QuestionLoaderServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	int qno=0;

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	questionBankLoader qbbloader=new questionBankLoader();
			List<Question>questions=qbbloader.loadQuestionOnJava();
			
		//	int qno=0;
			if(qno<questions.size())
			{
			Question question=questions.get(qno++);
			HttpSession ss=request.getSession();
			ss.setAttribute("curQs",question);
			
			response.sendRedirect("viewQuestion.jsp");
			}
			else
			{
				response.sendRedirect("viewScore.jsp");	
				}
	}

}
