package com.cdac.model;

import java.util.ArrayList;
import java.util.List;

public class questionBankLoader 
{
	public List<Question> loadQuestionOnJava()
	{
		QuestionBank qb=new QuestionBank();
		qb.addNewSubject("java");
		Question q=new Question("what is correct syntex to output \"hello World \"in java?");
		List<Option>ops=new ArrayList<Option>();
		ops.add(new Option("console .Writeln(...)",false));
		ops.add(new Option("out,println(...)",true));
		ops.add(new Option("echo(...)",false));
		ops.add(new Option("print(...)",false));
		q.setOptions(ops);
		qb.addNewQuestion("java", q);
		
		q=new Question("what is G1 in java?");
		ops=new ArrayList<Option>();
		ops.add(new Option("G1 is nickname of jeevan",false));
		ops.add(new Option("G1 is Sequence of srk Ra.one ",false));
		ops.add(new Option("G1 is Garbage Collecter ",false));
		ops.add(new Option("G1 is new movie of james bond",false));
		q.setOptions(ops);
		qb.addNewQuestion("java", q);
		
		q=new Question("what is JVM in java?");
		ops=new ArrayList<Option>();
		ops.add(new Option("java viral m/c",false));
		ops.add(new Option("java visual m/c ",false));
		ops.add(new Option("java Vinding m/c ",false));
		ops.add(new Option("java virtual m/c",true));
		q.setOptions(ops);
		qb.addNewQuestion("java", q);
		
		q=new Question("what happen when java code complied?");
		ops=new ArrayList<Option>();
		ops.add(new Option("Bytecode produced",true));
		ops.add(new Option("Native code is produced ",false));
		ops.add(new Option("Assembliy code is produced  ",false));
		ops.add(new Option("None of the above ",true));
		q.setOptions(ops);
		qb.addNewQuestion("java", q);
		
		return qb.fetchQuestionOn("java");
		
	}

}
