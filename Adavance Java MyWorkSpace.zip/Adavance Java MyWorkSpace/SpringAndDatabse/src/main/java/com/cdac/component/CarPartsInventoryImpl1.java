package com.cdac.component;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

import org.springframework.stereotype.Component;

import com.mysql.cj.xdevapi.PreparableStatement;
@Component("catInvPart1")
public class CarPartsInventoryImpl1 implements CarPartsInventory
{

	public void addParts(CarPart carParts) 
	{
		//TODO : Create the table first before running the code 
		// i.e  create table tbl_carparts(part_no int primary key auto_increment,part_name varchar(100),car_model varchar(100),price double,quantity int);
		Connection conn=null;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			long ms1=System.currentTimeMillis();
			conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/cdac", "root", "swapnil@1994");
			//PreparableStatement st=conn.prepareStatement("insert into tbl_carparts(part_name,part_model,price,quantity) values(?,?,?,?)");
		    long ms2=System.currentTimeMillis();
		    System.out.println("Approx time taken to connect "+(ms2-ms1)+"ms appox");
			PreparedStatement st=conn.prepareStatement("insert into tbl_carparts(part_name,car_model,price,quantity) values(?,?,?,?)");
			st.setString(1, carParts.getPartName());
			st.setString(2, carParts.getCarModel());
			st.setDouble(3, carParts.getPrice());
			st.setInt(4, carParts.getQuantity());
			st.executeUpdate();
			
			
		}catch(ClassNotFoundException | SQLException e)
		{
			e.printStackTrace();
		}
		finally {
			try {
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	
		
		
	}

	public List<CarPart> getAvailableParts() {
		// TODO Auto-generated method stub
		return null;
	}

}
