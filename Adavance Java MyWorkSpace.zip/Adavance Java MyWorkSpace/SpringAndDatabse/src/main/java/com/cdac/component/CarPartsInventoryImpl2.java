package com.cdac.component;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

import javax.sql.DataSource;
import javax.xml.crypto.Data;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.mysql.cj.xdevapi.PreparableStatement;
@Component("catInvPart2")
public class CarPartsInventoryImpl2 implements CarPartsInventory
{

	@Autowired
	private DataSource dataSource;
	public void addParts(CarPart carParts) 
	{
		
		Connection conn=null;
		try {
			//Class.forName("com.mysql.cj.jdbc.Driver"); // no need incase of dataSource
			long ms1=System.currentTimeMillis();
			//conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/cdac", "root", "swapnil@1994");// no need incase of dataSource
			conn=dataSource.getConnection();
			//PreparableStatement st=conn.prepareStatement("insert into tbl_carparts(part_name,part_model,price,quantity) values(?,?,?,?)");
		    long ms2=System.currentTimeMillis();
		    System.out.println("Approx time taken to connect "+(ms2-ms1)+"ms appox");
			PreparedStatement st=conn.prepareStatement("insert into tbl_carparts(part_name,car_model,price,quantity) values(?,?,?,?)");
			st.setString(1, carParts.getPartName());
			st.setString(2, carParts.getCarModel());
			st.setDouble(3, carParts.getPrice());
			st.setInt(4, carParts.getQuantity());
			st.executeUpdate();
			
			
		}catch( SQLException e)
		{
			e.printStackTrace();
		}
		finally {
			try
			{
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	
		
		
	}

	public List<CarPart> getAvailableParts() {
		// TODO Auto-generated method stub
		return null;
	}

}
