package com.cdac.app;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cdac.component.CarPart;
import com.cdac.component.CarPartsInventory;

public class App {

	public static void main(String[] args) 
	{
		ApplicationContext ctx=new ClassPathXmlApplicationContext("my-spring-config.xml");
		CarPartsInventory inv=(CarPartsInventory )ctx.getBean("catInvPart2");
		
		// Model/ Entity class  are not instantiated using spring 
		CarPart cp=new CarPart();
		cp.setPartName("Seat Cover");
		cp.setCarModel("Maruthi 800");
		cp.setPrice(500);
		cp.setQuantity(75);
		
		long ms1=System.currentTimeMillis();
		inv.addParts(cp);
		long ms2=System.currentTimeMillis();
		System.out.println(" total Approx time taken : "+(ms2-ms1)+"ms appox");

	}

}
